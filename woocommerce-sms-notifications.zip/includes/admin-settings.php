<?php

// Create admin menu for SMS settings
add_action('admin_menu', 'wc_sms_settings_menu');
function wc_sms_settings_menu() {
    add_menu_page(
        'SMS Settings',
        'SMS Settings',
        'manage_options',
        'sms-settings',
        'wc_sms_settings_page',
        'dashicons-email-alt',
        20
    );
}

// Admin settings page content
function wc_sms_settings_page() {
    if (isset($_POST['sms_save_settings'])) {
        update_option('sms_api_token', sanitize_text_field($_POST['sms_api_token']));
        update_option('sms_sid', sanitize_text_field($_POST['sms_sid']));
        update_option('sms_on_hold_message', sanitize_text_field($_POST['sms_on_hold_message']));
        update_option('sms_processing_message', sanitize_text_field($_POST['sms_processing_message']));
        update_option('sms_completed_message', sanitize_text_field($_POST['sms_completed_message']));
        update_option('sms_cancelled_message', sanitize_text_field($_POST['sms_cancelled_message']));
        echo '<div class="updated"><p>Settings saved</p></div>';
    }

    // Get saved settings
    $api_token = get_option('sms_api_token');
    $sid = get_option('sms_sid');
    $on_hold_message = get_option('sms_on_hold_message');
    $processing_message = get_option('sms_processing_message');
    $completed_message = get_option('sms_completed_message');
    $cancelled_message = get_option('sms_cancelled_message');

    ?>
    <div class="wrap">
        <h1>SMS Settings</h1>
        <form method="POST">
            <h2>API Credentials</h2>
            <label>API Token:</label>
            <input type="text" name="sms_api_token" value="<?php echo esc_attr($api_token); ?>" /><br><br>
            <label>SID:</label>
            <input type="text" name="sms_sid" value="<?php echo esc_attr($sid); ?>" /><br><br>

            <h2>SMS Templates</h2>
            <label>On-Hold Message:</label>
            <textarea name="sms_on_hold_message"><?php echo esc_textarea($on_hold_message); ?></textarea><br><br>
            <label>Processing Message:</label>
            <textarea name="sms_processing_message"><?php echo esc_textarea($processing_message); ?></textarea><br><br>
            <label>Completed Message:</label>
            <textarea name="sms_completed_message"><?php echo esc_textarea($completed_message); ?></textarea><br><br>
            <label>Cancelled Message:</label>
            <textarea name="sms_cancelled_message"><?php echo esc_textarea($cancelled_message); ?></textarea><br><br>

            <input type="submit" name="sms_save_settings" value="Save Settings" class="button button-primary">
        </form>
    </div>
    <?php
}
?>
