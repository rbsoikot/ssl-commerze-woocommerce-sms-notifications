<?php

// Hook into WooCommerce order status change
function wc_send_sms_on_status_change($order_id, $old_status, $new_status, $order) {
    $phone = $order->get_billing_phone();
    $name = $order->get_billing_first_name();
    $message = '';

    // Get the appropriate message based on the order status
    if ($new_status == 'on-hold') {
        $message = get_option('sms_on_hold_message');
    } elseif ($new_status == 'processing') {
        $message = get_option('sms_processing_message');
    } elseif ($new_status == 'completed') {
        $message = get_option('sms_completed_message');
    } elseif ($new_status == 'cancelled') {
        $message = get_option('sms_cancelled_message');
    }

    if ($message) {
        // Replace placeholders with real data
        $message = str_replace('{id}', $order_id, $message);
        $message = str_replace('{name}', $name, $message);

        // Send the SMS
        wc_send_sms($phone, $message);
    }
}

// Send SMS using the iSMS Plus API
function wc_send_sms($msisdn, $message) {
    $api_token = get_option('sms_api_token');
    $sid = get_option('sms_sid');
    $csmsId = uniqid(); // Unique CSMS ID

    $params = [
        "api_token" => $api_token,
        "sid" => $sid,
        "msisdn" => $msisdn,
        "sms" => $message,
        "csms_id" => $csmsId
    ];

    $url = "https://smsplus.sslwireless.com/api/v3/send-sms";
    $response = wp_remote_post($url, [
        'method' => 'POST',
        'body' => json_encode($params),
        'headers' => [
            'Content-Type' => 'application/json'
        ]
    ]);

    if (is_wp_error($response)) {
        error_log('SMS Error: ' . $response->get_error_message());
    }
}
?>
