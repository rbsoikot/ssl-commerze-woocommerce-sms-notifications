<?php

// Create admin menu for SMS settings
add_action('admin_menu', 'wc_sms_settings_menu');
function wc_sms_settings_menu() {
    add_menu_page(
        'SMS Notifications Settings',
        'SMS Notifications',
        'manage_options',
        'sms-settings',
        'wc_sms_settings_page',
        'dashicons-email-alt', // Icon for the admin menu
        20
    );
}

// Admin settings page content
function wc_sms_settings_page() {
    // Handle form submission
    if (isset($_POST['sms_save_settings'])) {
        update_option('sms_api_token', sanitize_text_field($_POST['sms_api_token']));
        update_option('sms_sid', sanitize_text_field($_POST['sms_sid']));
        update_option('sms_on_hold_message', sanitize_text_field($_POST['sms_on_hold_message']));
        update_option('sms_processing_message', sanitize_text_field($_POST['sms_processing_message']));
        update_option('sms_completed_message', sanitize_text_field($_POST['sms_completed_message']));
        update_option('sms_cancelled_message', sanitize_text_field($_POST['sms_cancelled_message']));
        echo '<div class="notice notice-success is-dismissible"><p>Settings saved successfully.</p></div>';
    }

    // Retrieve saved settings
    $api_token = get_option('sms_api_token');
    $sid = get_option('sms_sid');
    $on_hold_message = get_option('sms_on_hold_message');
    $processing_message = get_option('sms_processing_message');
    $completed_message = get_option('sms_completed_message');
    $cancelled_message = get_option('sms_cancelled_message');

    ?>
    <div class="wrap">
        <h1 class="wp-heading-inline">SMS Notifications Settings</h1>
        <p>Configure your SMS API credentials and custom messages for order status changes.</p>

        <form method="POST" action="" class="form-table">
            <h2 class="title">API Credentials</h2>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="sms_api_token">API Token</label></th>
                    <td><input type="text" name="sms_api_token" id="sms_api_token" value="<?php echo esc_attr($api_token); ?>" class="regular-text" placeholder="Enter your API token"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="sms_sid">SID</label></th>
                    <td><input type="text" name="sms_sid" id="sms_sid" value="<?php echo esc_attr($sid); ?>" class="regular-text" placeholder="Enter your SID"></td>
                </tr>
            </table>

            <h2 class="title">SMS Templates</h2>
            <p>Use <code>{id}</code> for Order ID, <code>{name}</code> for Customer Name, <code>{price}</code> for Product Price, <code>{currency}</code> for Currency, and <code>{order_number}</code> for Order Number in your messages.</p>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="sms_on_hold_message">On-Hold Message</label></th>
                    <td><textarea name="sms_on_hold_message" id="sms_on_hold_message" rows="4" class="large-text" placeholder="Enter the SMS message for 'On-Hold' status"><?php echo esc_textarea($on_hold_message); ?></textarea></td>
                </tr>
                <tr>
                    <th scope="row"><label for="sms_processing_message">Processing Message</label></th>
                    <td><textarea name="sms_processing_message" id="sms_processing_message" rows="4" class="large-text" placeholder="Enter the SMS message for 'Processing' status"><?php echo esc_textarea($processing_message); ?></textarea></td>
                </tr>
                <tr>
                    <th scope="row"><label for="sms_completed_message">Completed Message</label></th>
                    <td><textarea name="sms_completed_message" id="sms_completed_message" rows="4" class="large-text" placeholder="Enter the SMS message for 'Completed' status"><?php echo esc_textarea($completed_message); ?></textarea></td>
                </tr>
                <tr>
                    <th scope="row"><label for="sms_cancelled_message">Cancelled Message</label></th>
                    <td><textarea name="sms_cancelled_message" id="sms_cancelled_message" rows="4" class="large-text" placeholder="Enter the SMS message for 'Cancelled' status"><?php echo esc_textarea($cancelled_message); ?></textarea></td>
                </tr>
            </table>

            <p class="submit">
                <input type="submit" name="sms_save_settings" id="sms_save_settings" class="button button-primary" value="Save Changes">
            </p>
        </form>
    </div>
    <?php
}
?>
